# Hello.py

This is a lesson from [Insper's open dev course](https://github.com/Insper/open-dev). It is an example pypi module.
